/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filemanager;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author Marcela Torres & Johan Aponte
 */
public class FileManager {

    /**
     * @param args the command line arguments
     */
    
    private String nombre;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
 
    public static void main(String[] args) throws IOException {

        final String EXTENSION = ".txt";
        String nombreArchivo;
        String nombreArchivo2;
        String nombreArchivo3;
        String nombreArchivoGeneral = "";
        Scanner scan = new Scanner(System.in);
        System.out.println("Ingrese el nombre del archivo.");
        //Punto 1: Asignar "nombre de archivo" a var_identifier
        nombreArchivo = scan.nextLine();
        System.out.println("Ingrese el nombre del archivo 2.");
        nombreArchivo2 = scan.nextLine();
        System.out.println("Ingrese el nombre del archivo 3.");
        nombreArchivo3 = scan.nextLine();
        scan.close();

        File f1 = new File(nombreArchivo + EXTENSION);
        f1.createNewFile();
        File f2 = new File(nombreArchivo2 + EXTENSION);
        f2.createNewFile();
        File f3 = new File(nombreArchivo3 + EXTENSION);
        f3.createNewFile();
        //Punto 2: Asignar a variable el archivo (var_identifier)
        //Punto 3: Identificador de variable (var_id1 = var_id2)
        BufferedWriter writer = new BufferedWriter(new FileWriter(f1));
        writer.write(nombreArchivo);
        writer.flush();

        BufferedWriter writer2 = new BufferedWriter(new FileWriter(f2));
        writer2.write(nombreArchivo2);
        writer2.flush();

        BufferedWriter writer3 = new BufferedWriter(new FileWriter(f3));
        writer3.write(nombreArchivo3);
        writer3.flush();

        FileOutputStream idArchivo1Output = new FileOutputStream(f1);
        FileInputStream idArchivo2Input = new FileInputStream(f2);
        FileInputStream idArchivo3Input = new FileInputStream(f3);

        Scanner sc = new Scanner(idArchivo2Input);  
        Scanner sc2 = new Scanner(idArchivo3Input);

        f1 = f2;

        while (sc.hasNext()) {
            String next = sc.next();
            writer.write(next);
            writer.flush();
        }

        while (sc2.hasNext()) {
            String next = sc2.next();
            writer.write(next);
            writer.flush();
        }
        writer.close();
         

        File file = new File("C:\\Users\\User\\Desktop\\archivo1.txt");
        File file2 = new File("C:\\Users\\User\\Desktop\\archivo2.txt");
        Scanner input = new Scanner(file);

        int count = 0;
        ArrayList<String> palabras = new ArrayList<>();
        while (input.hasNext()) {
            String word = input.next();
            palabras.add(word);
            System.out.println(palabras.get(count));
            count = count + 1;
        }
        System.out.println("Word count: " + count);

        
        /*ArrayList<String> palabras2 = new ArrayList<>();
        Scanner input2 = new Scanner(file2);
        while (input2.hasNext()) {
            palabras2.add(input2.next());
        }
        Iterator<String> it = palabras2.listIterator();

        ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(file2));

        List<String> deduped = list.stream().distinct().collect(Collectors.toList());

        palabras2.forEach(
                (s) -> {
                    System.out.println("Contenido" + s);
                }
        );
*/
        int tam = palabras.size() - 1;
        for (int i = 0;
                i < tam;
                ++i) {
            for (int j = i + 1; j < palabras.size(); ++j) {
                if (palabras.get(i).compareTo(palabras.get(j)) > 0) {
                    // swap words[i] with words[j[
                    String temp = palabras.get(i);
                    palabras.set(i, palabras.get(j));
                    palabras.set(j, temp);
                }
            }
        }

        System.out.println(
                "In lexicographical order:");

        for (int i = 0;
                i < palabras.size();
                i++) {
            System.out.println(palabras.get(i));
        }

        Collections.sort(palabras);
        for (String palabra : palabras) {
            System.out.println("Sort: " + palabra);
        }

    }

}
